import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithCustomToken, signOut as fbSignOut } from 'firebase/auth';
import {
  addDoc, collection, doc, getDoc, getFirestore, onSnapshot, query,
  runTransaction, serverTimestamp, updateDoc, where
} from 'firebase/firestore';

const env = import.meta.env;
const config = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  appId: env.VITE_FIREBASE_APP_ID
};
const configured = Object.values(config).every((v) => v && !String(v).includes('replace_with') && !String(v).includes('your-project'));

const ACTIVE_DRIVER_STATUSES = ['accepted', 'arrived', 'in_progress'];

function notifyError(message) {
  if (typeof window.onArideFirebaseError === 'function') window.onArideFirebaseError(message);
}

async function postJson(url, body, authenticated) {
  const headers = { 'Content-Type': 'application/json' };
  if (authenticated) Object.assign(headers, await api.authHeaders());
  let response;
  try {
    response = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
  } catch {
    throw new Error('Could not reach the ARIDE server. Check your connection.');
  }
  let data = {};
  try { data = await response.json(); } catch { /* non-JSON error page */ }
  if (!response.ok) {
    throw new Error(data.message || 'The ARIDE server is unavailable. Run "npm run dev:vercel" locally, or deploy to Vercel.');
  }
  return data;
}

let auth = null;
let db = null;
const locationWatches = new Map();

const api = {
  configured,
  get currentUser() { return auth ? auth.currentUser : null; },

  async authHeaders() {
    if (!auth || !auth.currentUser) throw new Error('Please sign in first.');
    return { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` };
  },

  // ---- Email OTP sign-in (server verifies, then issues a Firebase custom token) ----
  async sendEmailOtp(email) {
    await postJson('/api/auth/send-otp', { email }, false);
  },
  async verifyEmailOtp(email, code) {
    const { token } = await postJson('/api/auth/verify-otp', { email, code }, false);
    await signInWithCustomToken(auth, token);
  },
  async signOut() {
    api.stopAllLocationSharing();
    await fbSignOut(auth);
  },

  // ---- Customer ----
  async createRideRequest(ride) {
    const user = auth.currentUser;
    const ref = await addDoc(collection(db, 'rideRequests'), {
      customerUid: user.uid,
      pickup: ride.pickup,
      drop: ride.drop,
      pickupCoordinates: ride.pickupCoordinates,
      dropCoordinates: ride.dropCoordinates,
      vehicleType: ride.vehicleType,
      fare: ride.fare,
      couponCode: ride.couponCode || '',
      paymentMethod: ride.paymentMethod,
      status: 'searching',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return ref.id;
  },
  watchRideRequest(rideId, onRide, onError) {
    return onSnapshot(doc(db, 'rideRequests', rideId),
      (snap) => { if (snap.exists()) onRide({ id: snap.id, ...snap.data() }); },
      onError);
  },
  async cancelRideRequest(rideId) {
    await updateDoc(doc(db, 'rideRequests', rideId), { status: 'canceled', updatedAt: serverTimestamp() });
  },

  // ---- Driver ----
  subscribeOpenRideRequests(onRides, onError) {
    const q = query(collection(db, 'rideRequests'), where('status', '==', 'searching'));
    return onSnapshot(q, (snap) => {
      const rides = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      rides.sort((a, b) => (a.createdAt?.toMillis?.() ?? Infinity) - (b.createdAt?.toMillis?.() ?? Infinity));
      onRides(rides);
    }, onError);
  },
  subscribeDriverRides(onRides, onError) {
    const q = query(collection(db, 'rideRequests'), where('driverUid', '==', auth.currentUser.uid));
    return onSnapshot(q, (snap) => {
      onRides(snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((r) => ACTIVE_DRIVER_STATUSES.includes(r.status)));
    }, onError);
  },
  async acceptRideRequest(rideId) {
    const uid = auth.currentUser.uid;
    const rideRef = doc(db, 'rideRequests', rideId);
    const driverRef = doc(db, 'drivers', uid);
    await runTransaction(db, async (tx) => {
      const [rideSnap, driverSnap] = await Promise.all([tx.get(rideRef), tx.get(driverRef)]);
      if (!driverSnap.exists() || driverSnap.data().approved !== true) throw new Error('Your driver account is not approved.');
      if (!rideSnap.exists() || rideSnap.data().status !== 'searching') throw new Error('Another driver already took this ride.');
      const driver = driverSnap.data();
      tx.update(rideRef, {
        status: 'accepted',
        driverUid: uid,
        driverName: driver.name,
        driverVehicle: driver.vehicle,
        updatedAt: serverTimestamp()
      });
    });
  },
  async updateDriverRideStatus(rideId, status) {
    await updateDoc(doc(db, 'rideRequests', rideId), { status, updatedAt: serverTimestamp() });
    if (status === 'arrived') {
      try {
        await api.sendTripStartOtp(rideId);
      } catch (error) {
        throw new Error('Marked as arrived, but the trip code email failed: ' + error.message + ' Tap "Resend trip code".');
      }
    }
  },
  async sendTripStartOtp(rideId) {
    await postJson('/api/ride/send-trip-otp', { rideId }, true);
  },
  async verifyTripStartOtp(rideId, code) {
    await postJson('/api/ride/verify-trip-otp', { rideId, code }, true);
  },
  async setDriverAvailability(available) {
    await updateDoc(doc(db, 'drivers', auth.currentUser.uid), { available: Boolean(available), updatedAt: serverTimestamp() });
  },
  startDriverLocationSharing(rideId) {
    if (!('geolocation' in navigator)) throw new Error('This device does not support location sharing.');
    api.stopLocationSharing(rideId);
    let lastSent = 0;
    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        if (Date.now() - lastSent < 5000) return;
        lastSent = Date.now();
        try {
          await updateDoc(doc(db, 'rideRequests', rideId), {
            driverLocation: { latitude: pos.coords.latitude, longitude: pos.coords.longitude },
            updatedAt: serverTimestamp()
          });
        } catch {
          api.stopLocationSharing(rideId); // ride finished or rules rejected the write
        }
      },
      (error) => { api.stopLocationSharing(rideId); notifyError('Location sharing stopped: ' + error.message); },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 15000 }
    );
    locationWatches.set(rideId, watchId);
  },
  stopLocationSharing(rideId) {
    if (locationWatches.has(rideId)) {
      navigator.geolocation.clearWatch(locationWatches.get(rideId));
      locationWatches.delete(rideId);
    }
  },
  stopAllLocationSharing() {
    [...locationWatches.keys()].forEach((id) => api.stopLocationSharing(id));
  }
};

async function loadAccess(user) {
  if (!user) return { driverApproved: false, driverProfile: null };
  try {
    const snap = await getDoc(doc(db, 'drivers', user.uid));
    const profile = snap.exists() ? snap.data() : null;
    return { driverApproved: Boolean(profile && profile.approved === true), driverProfile: profile };
  } catch {
    return { driverApproved: false, driverProfile: null };
  }
}

window.ARIDEFirebase = api;

if (configured) {
  const app = initializeApp(config);
  auth = getAuth(app);
  db = getFirestore(app);
  onAuthStateChanged(auth, async (user) => {
    const access = await loadAccess(user);
    if (typeof window.onArideAuthChanged === 'function') window.onArideAuthChanged(user, access);
  });
} else if (typeof window.onArideAuthChanged === 'function') {
  window.onArideAuthChanged(null, { driverApproved: false, driverProfile: null });
}
