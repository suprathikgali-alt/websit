// Registers the service worker (production only) and shows an "Install app" button.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((error) => console.warn('ARIDE service worker failed:', error));
  });
}

let deferredPrompt = null;
const button = document.createElement('button');
button.type = 'button';
button.textContent = 'Install ARIDE app';
button.setAttribute('aria-label', 'Install the ARIDE app on this device');
button.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:9999;display:none;padding:12px 18px;border:0;border-radius:999px;background:#A4863D;color:#0E300E;font:800 14px "Plus Jakarta Sans",sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer';
document.addEventListener('DOMContentLoaded', () => document.body.appendChild(button));

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredPrompt = event;
  button.style.display = 'block';
});
button.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  button.style.display = 'none';
});
window.addEventListener('appinstalled', () => { button.style.display = 'none'; });
